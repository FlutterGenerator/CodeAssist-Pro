package $packagename.game;

import com.badlogic.gdx.ApplicationListener;

/**
* @author Mutwakil Suliman (Wadamzmail)
* https://github.com/Wadamzmail
*/

public class MyGdxGame implements ApplicationListener{
  //TODO: make it extends com.badlogic.gdx.Game if you want to manage screens
    
	@Override
	public void create() {
		
	}

	@Override
	public void render() {
		
	}


	@Override
	public void pause() {
		
	}

	@Override
	public void resize(int arg0, int arg1) {
		
	}

	@Override
	public void resume() {
		
	}

	@Override
	public void dispose() {
		
	}

}